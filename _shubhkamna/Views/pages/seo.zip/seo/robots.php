User-agent: *
Disallow: /cgi-bin/
Sitemap: <?php echo base_url() ?>/sitemap.xml

